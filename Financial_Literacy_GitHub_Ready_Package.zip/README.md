# 💰 Digital Financial Literacy Chatbot

This is a simple HTML/JS chatbot that helps users understand UPI, budgeting, loans, and fraud safety.

## 🌟 Features
- UPI help and safety tips
- Loan interest info
- Budgeting rules
- Scam protection
- Works offline in browser

## 🛠 Tech Used
- HTML, CSS, JavaScript
- No external libraries
- Fully browser-based demo

## 🚀 How to Run
1. Download the `index.html` file
2. Double-click to open in your browser
3. Start chatting!

## 📚 Use Case
This project was developed for the IBM SkillsBuild Hackathon 2025 under Problem Statement 7: AI Agent for Digital Financial Literacy.
